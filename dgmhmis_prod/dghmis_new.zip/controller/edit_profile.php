<?php

require_once("config.php");
session_start();
if(isset($_SESSION['email'])){
    $conn=get_db_connection();
    $name=$_POST['name'];
    $email=$_POST['email'];
    $phone=$_POST['phone'];
    $designation=$_POST['designation'];
    $id=$_POST['id'];
    $sql="update user set `name`='$name', `email`='$email', `phone`='$phone',`designation`='$designation' where id=$id";
    $result=mysqli_query($conn,$sql);
    $row=mysqli_fetch_assoc($result);
}

else{
    header('location:../index.php');
}


?>