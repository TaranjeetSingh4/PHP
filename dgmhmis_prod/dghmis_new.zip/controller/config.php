<?php

function get_db_connection($db_host='localhost',$db_user='dev',$db_password='sUUR2mZM1fR5WfKp',$db_name='template'){
    $conn = mysqli_connect($db_host,$db_user,$db_password,$db_name);
    if(!$conn){
        die("Connection failed: " . mysqli_connect_error());
    }
    return $conn;
}

?>
