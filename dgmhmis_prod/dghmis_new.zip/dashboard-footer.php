				 <!-- InstanceEndEditable -->  
                 </div>
                </div>
                <div class="clearfix"></div>
                <div class="foot">
Design & Developed by: <a href="https://www.appventurez.com/" target="_blank"><strong style="color:#007BFF;">Appventurez</strong><strong> Mobitech</strong> Pvt. Limited</a> through <a href="https://www.dgmhup.gov.in/" target="_blank"><strong>DGMHUP</strong></a> . This portal is maintained &amp; managed by IT Cell, DGMHUP, Uttar Pradesh.
</div>
            </section>
        </div>
    </div>

    <?php
    require_once './controller/config.php';

    $conn=get_db_connection();
    
    $query="select * from roles order by role asc";
    $result=mysqli_query($conn,$query);

    ?>


    <script type="text/javascript" src="js/jquery-1.11.3.min.js"></script>
    <script src="//cdn.datatables.net/2.1.2/js/dataTables.min.js"></script>
    <script type="text/javascript" src="js/app.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script> 
    <script type="text/javascript" src="js/bootstrap-select.min.js"></script> 
    <script type="text/javascript" src="js/owl.carousel.min.js"></script> 
    <script type="text/javascript" src="js/bootstrap-multiselect.js"></script> 
    <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
   

    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script> -->

    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script> -->
    <script>
	$(document).ready(function() {
	$('a').each(function(){
	if(location.href === this.href){
	$(this).addClass('active');
	$('a').not(this).addClass('none');
	return false;
	}
	});
	});
	$(function () {
        $(".spotlgt").owlCarousel({
            slideSpeed: 300,
            paginationSpeed: 400,
            items: 1,
            autoPlay: !0,
            navigation: !0,
			pagination: false,
			itemsDesktop : [1199,1],
            itemsDesktopSmall : [1027,1],
            navigationText: ["<i class='icon-arrow-left icons'></i>", "<i class='icon-arrow-right icons'></i>"]
        }); 
		
		});
	</script>
    <script src="js/jquery.bootstrap.wizard.js"></script>
    <script src="js/prettify.js"></script>
	<script>
    $(document).ready(function() {
    $('#rootwizard').bootstrapWizard({'tabClass': 'bwizard-steps'});
    window.prettyPrint && prettyPrint()
    });
    </script>
	<script src="Scripts/SelfDeclarationOfHT.js"></script>
    <script>

    $(document).ready(function(){
        $(".add_item_btn").click(function(e){
            e.preventDefault();
            $("#show_item").append(`<div class="row append_item" id="remove_item">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Field Name <span class="star">*</span></label>
                                        <input name="field_name[]" class="form-control" type="text">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Field Type <span class="star">*</span></label>
                                        <select name="field_type[]" style="width:100%;">
                                                <option value="text">String</option>
                                                <option value="number">Integer</option>
                                                <option value="file">File</option>
                                        </select>
                                       
                                    </div>
                                </div>
                                <div class="col-md-4 mt-2">
                                    <div class="form-group">
                                        <button class="remove_item_btn btn btn-danger">Remove Field</button>
                                    </div>
                                </div>
                            </div>`);
        });

        $(".add_section_btn").click(function(e){
            e.preventDefault();
            $("#show_section").append(`<div class="row append_section">
                <div class="col-md-3">
                    <div class="form-group">
                        <label>Section Name <span class="star">*</span></label>
                        <input name="section_name[]" class="form-control" type="text">
                    </div>
                </div>

                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Sub-Field Name <span class="star">*</span></label>
                                        <input name="sub_field_name[]" class="form-control" type="text">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Sub Field Type <span class="star">*</span></label>
                                        <select name="sub_field_type[]" style="width:100%;">
                                                <option value="text">String</option>
                                                <option value="number">Integer</option>
                                                <option value="file">File</option>
                                        </select>
                                       
                                    </div>
                                </div>
                <div class="col-md-2 mt-2">
                    <div class="form-group">
                        <button class="add_sub btn btn-success">Add More Fields</button>
                    </div>
                </div>

                <div class="col-md-1 mt-2">
                    <div class="form-group">
                        <button class="remove_item_btn btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></button>
                    </div>
                </div>
                
                
            </div>`);
        });


        $('.add_user_btn').click(function(e){
            e.preventDefault();
            $("#show_user_section").append(`<div class="row append_section " style="margin:1px"><div class="col-md-2 col-xs-12">
                            <div class="form-group">
                                <label>Name <span class="star">*</span></label>
                                <input required name="name[]" class="form-control" type="text">
                            </div>
                        </div>
               
                        <div class="col-md-3 col-xs-12">
                            <div class="form-group">
                                <label>Email ID <span class="star">*</span></label>
                                <input required name="email[]" class="form-control" type="email">
                            </div>
                        </div>

                        <div class="col-md-2 col-xs-12">
                            <div class="form-group">
                                <label>Mobile No. <span class="star">*</span></label>
                                <input required name="phone[]" class="form-control" type="text">
                            </div>
                        </div>
                        <div class="col-md-2 col-xs-12">
                            <div class="form-group">
                                <label>Designation <span class="star">*</span></label>
                                <input required name="designation[]d" class="form-control" type="text">
                            </div>
                        </div>
                        <div class="col-md-2 col-xs-12">
                            <div class="form-group">
                                <label>Role <span class="star">*</span></label>
                                <select name="role[]" class="form-control">
                                    <option value="null" id="choose-role" style="color:grey">--------- Choose Role ----------</option>
                                   
                                    <?php
                                    while($row=mysqli_fetch_assoc($result)){
                                      
                                    ?>
                                    <option value="<?php echo $row['id'] ?>"><?php echo $row['role']; ?></option>
                                    <?php    
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-1 mt-2">
                            <button class="remove_user_btn"><i class="fa fa-trash" aria-hidden="true" style="font-size:2rem; background:red; color:white; padding:10px"></i></button>
                        </div></div>`);
        });

        $(document).on('click','.remove_user_btn',function(e){
            e.preventDefault();
            let row_item=$(this).parent().parent();
            let id=this.id;
            
            $(row_item).remove();
            
        });


        $(document).on('click','.add_sub',function(e){
            e.preventDefault();
           $("#show_section").append(`<div class="row append_item" id="remove_item">
           <div class="col-md-3">
                    <div class="form-group">
                        <label>Section Name <span class="star">*</span></label>
                        <input name="section_name[]" class="form-control" type="text">
                    </div>
                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Sub-Field Name <span class="star">*</span></label>
                                        <input name="sub_field_name[]" class="form-control" type="text">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Sub Field Type <span class="star">*</span></label>
                                        <select name="sub_field_type[]" style="width:100%;">
                                                <option value="text">String</option>
                                                <option value="number">Integer</option>
                                                <option value="file">File</option>
                                        </select>
                                       
                                    </div>
                                </div>
                                <div class="col-md-3 mt-2">
                                    <div class="form-group">
                                        <button class="remove_item_btn btn btn-danger">Remove Field</button>
                                    </div>
                                </div>
                            </div>`);
        });
  
        let count=[];
        $(document).on('click','.remove_item_btn',function(e){
            e.preventDefault();
            let row_item=$(this).parent().parent().parent();
            let id=this.id;
            
            if(this.id){
                count.push(id);
                let element=document.getElementById('delete_field_id');
                element.value=count;
                $(row_item).remove();
            }
            else{
                $(row_item).remove();
            }
        });

        let sub_field_count=[]
        $(document).on('click','.remove_sub_field_btn',function(e){
            e.preventDefault();
            let row_item=$(this).parent().parent().parent();
            let id=this.id;
            
            if(this.id){
                sub_field_count.push(id);
                let element=document.getElementById('delete_sub_field_id');
                element.value=sub_field_count;
                $(row_item).remove();
            }
            else{
                $(row_item).remove();
            }
        });



       
            $('#roles').multiselect({
               buttonWidth:'100px',
                includeSelectAllOption: true,
            });

            $('#multiple-roles').multiselect({
               buttonWidth:'200px',
                includeSelectAllOption: true,
            });

            $('#formats').multiselect({
               buttonWidth:'200px',
                includeSelectAllOption: true,
            });

            // $('#format_mapping_form').on('submit', function(event){
            //     event.preventDefault();
            //     var form_data = $(this).serialize();
            //     $.ajax({
            //     url:"./controller/edit_mapping.php",
            //     method:"POST",
            //     data:form_data,
            //     success:function(data)
            //         {
            //             location.reload();
            //             // alert(data);
            //             // $('#roles option:selected').each(function(){
            //             //     $(this).prop('selected', false);
            //             //     });
            //             // $('#roles').multiselect('refresh');
            //             // alert(data);
            //         }
            //     });
            // });

            $('#format-mapping-form').on('submit', function(event){
                event.preventDefault();
                var form_data = $(this).serialize();
                $.ajax({
                url:"./controller/add_mapping.php",
                method:"POST",
                data:form_data,
                success:function(data)
                    {
                        location.reload();
                        //alert(data);
                        // $('#roles option:selected').each(function(){
                        //     $(this).prop('selected', false);
                        //     });
                        // $('#roles').multiselect('refresh');
                        // alert(data);
                    }
                });
            });

            $('#edit_format_mapping_form').on('submit', function(event){
                event.preventDefault();
                var form_data = $(this).serialize();
                $.ajax({
                url:"./controller/edit_mapping.php",
                method:"POST",
                data:form_data,
                success:function(data)
                    {
                       
                        window.location='mapping-template.php';
                        
                    }
                });
            });
        



        //ajax request to insert all form data

        $("#add_form").submit(function(e){
            e.preventDefault();
            $("#add_btn").val('Adding.....');
            $.ajax({
                url: './controller/action.php',
                method:'post',
                data: $(this).serialize(),
                success: function(response){
                    // console.log(response);
                    window.location='dashboard.php';
                    // $("#add_btn").val('Add');
                    // $("#add_form")[0].reset();
                    // $(".append_item").remove();
                    // $(".append_section").remove();
                    // $("#show_alert").html(`<h5>${response}</h5>`);
                }
            });
        });

        $("#edit_form").submit(function(e){
            e.preventDefault();
            $("#edit_btn").val('Updating.....');
            $.ajax({
                url: './controller/edit_format.php',
                method:'post',
                data: $(this).serialize(),
                success: function(response){
                    // console.log(response);
                    $("#edit_btn").val('Edit');
                    // // $("#edit_form")[0].reset();
                    $(".append_item").remove();
                    location.reload();
                    $("#show_alert").html(`<h5>${response}</h5>`);
                }
            });
        });

        $("#edit_profile_form").submit(function(e){
            e.preventDefault();
            $("#edit_profile_btn").val('Updating.....');
            $.ajax({
                url: './controller/edit_profile.php',
                method:'post',
                data: $(this).serialize(),
                success: function(response){
                    // console.log(response);
                    $("#edit_profile_btn").val('Save');
                    // // $("#edit_form")[0].reset();
                    // $(".append_item").remove();
                    location.reload();
                    // $("#show_alert").html(`<h5>${response}</h5>`);
                }
            });
        });

        $("#change_password_form").submit(function(e){
            e.preventDefault();
            $("#change_password_btn").val('Updating.....');
            $.ajax({
                url: './controller/change_password.php',
                method:'post',
                data: $(this).serialize(),
                success: function(response){
                    // console.log(response);
                    $("#change_password_btn").val('Change Password');
                    // $("#change_password_form").reset();
                    // $(".append_item").remove();
                    // location.reload();
                    $("#show_alert").html(`<h5>${response}</h5>`);
                }
            });
        });


        $("#filter_form").submit(function(e){
            e.preventDefault();
            $.ajax({
                url: './controller/filters.php',
                type: 'post',
                data:$(this).serialize(),
                // type: 'post',
                dataType: 'JSON',   
                success: function(response){
                    // alert(response);
                    let data=JSON.stringify(response);
                    // alert(data);
                    if(data=="null"){
                        $("#userTableFilter").hide();
                        $("#error_show").removeClass('hidden');
                        $("#error_show").text('No Data Found');
                        var len=0;
                    }
                    else{
                        $("#error_show").addClass('hidden');
                        $("#userTableFilter").show();
                        var len = response.length;
                    }
                    

                    $("#userTable").hide();
                    $("#userTableFilter").removeClass('hidden');
                    $('#userTableFilter tbody').empty();
                    

                    for(var i=0; i<len; i++){
                        var id = response[i].id;
                        var name = response[i].name;
                        var email = response[i].email;
                        var phone=response[i].phone;
                        var designation=response[i].designation;
                        var role=response[i].roles_array;
                        var pwd=response[i].password;
                        var district=response[i].district_name;
                        var status=response[i].status;


                        var tr_str = "<tr>" +
                            "<td>" + (i+1) + "</td>" +
                            "<td>" + name + "</td>" +
                            "<td>" + email + "</td>" +
                            "<td>" + pwd + "</td>" +
                            "<td>" + phone + "</td>" +
                            "<td>" + district + "</td>" +
                            "<td>" + designation + "</td>" +
                            "<td>" + role + "</td>" +
                            "<td>" + status + "</td>" +
                            
                            ` <td>
                                    <a href="edit-user.php?id=${id}"><i class="fa fa-pencil edit" aria-hidden="true" style="margin-right:20px"></i> </a>
                                    <a href="./controller/delete_user.php?id=${id}"><i class="fa fa-trash delete" aria-hidden="true"></i></a>
                            </td>` +
                            ` <td>
                                    <a href="./controller/send-message.php?id=${id}"><button class="btn btn-block btn-primary text-center">Send Message</button></a>
                                    
                            </td>` 
                            "</tr>";
                       
                        
                        $("#userTableFilter tbody").append(tr_str);
                    }
                   
                    
                }
            });
        });


        $(document).ready(function(){
            $.ajax({
                url: './controller/get_user_lisitng.php',
                type: 'get',
        //type: 'post',
                dataType: 'JSON',
                success: function(response){
                    // alert(response);
                    let data=JSON.stringify(response);
                    var len = response.length;
                    
                    for(var i=0; i<len; i++){
                        var id = response[i].id;
                        var name = response[i].name;
                        var email = response[i].email;
                        var phone=response[i].phone;
                        var designation=response[i].designation;
                        var role=response[i].roles_array;
                        var pwd=response[i].password;
                        var district=response[i].district_name;
                        var total_users_in_district=response[i].total_district_user_count;
                        var filled_data_user_count=response[i].filled_data_user_count;
                        var status=response[i].status;

                        
                        // var last_login=response[i].last_login;
                        // var last_logout=response[i].last_logout;


                        var tr_str = "<tr>" +
                            "<td>" + (i+1) + "</td>" +
                            "<td>" + name + "</td>" +
                            "<td>" + email + "</td>" +
                            "<td>" + pwd + "</td>" +
                            "<td>" + phone + "</td>" +
                            "<td>" + district + "</td>" +
                            "<td>" + role + "</td>" +
                            "<td>" + designation + "</td>" +
                            "<td>" + total_users_in_district + "</td>" +
                            "<td>" + filled_data_user_count + "</td>" +
                            "<td>" + status + "</td>" +
                            
                            
                            ` <td>
                                    <a href="edit-user.php?id=${id}"><i class="fa fa-pencil edit" aria-hidden="true" style="margin-right:20px"></i> </a>
                                    <a href="./controller/delete_user.php?id=${id}"><i class="fa fa-trash delete" aria-hidden="true"></i></a>
                            </td>` +
                            ` <td>
                                    <a href="./controller/send-message.php?id=${id}"><button class="btn btn-block btn-primary text-center">Send Message</button></a>
                                    
                            </td>` 
                            "</tr>";
                        
                        $("#userTable tbody").append(tr_str);

                    }

                }
            });
        });


        $("#listing_type").on('change', function(){
            let val = $(this).val();  
            // alert(val);
            
                $.ajax({
                url: './controller/fetch_info.php',
                method:'get',
                dataType: 'JSON',
                data: {value:val},
                success: function(response){
                    let data=JSON.stringify(response);
                    
                    if(response.length==0){
                        $('#no-data').removeClass('hidden');
                        $('#no-data').text('No Data Found !');
                    }
                    else{
                        $('#no-data').addClass('hidden');
                    }
                    var len = response.length;
                    if(val=='active'){
                        var heading_name="Active Templates Listing";
                    }
                    else if(val=='inactive'){
                        var heading_name="Active Templates Listing";
                    }
                    else{
                        var heading_name="All Templates Listing";
                    }

                    $('#type-of-template-listing').text(heading_name);

                    $("#default-listing-table").hide();
                    $("#filter-listing-table").removeClass('hidden');
                    $('#filter-listing-table tbody').empty();
                    
                    for(var i=0; i<len; i++){
                        var id = response[i].id;
                        var format_name = response[i].format_name;
                        var format_heading = response[i].format_heading;
                        var status=response[i].format_status;
                        if(status==1){
                            var status_icon="fa-toggle-on";
                            var active="active";
                        }
                        else{
                            var status_icon="fa-toggle-off";
                            var active="inactive";
                        }

                        

                        var tr_str = "<tr>" +
                            "<td><strong>" + (i+1) + "</strong></td>" +
                            "<td><strong>" + format_name + "</strong></td>" +
                            "<td><strong>" + format_heading + "</strong></td>" +
                            ` <td><strong>
                                    <a href="./controller/delete-template.php?id=${id}&status=${status}"><i class="fa ${status_icon} ${active}" aria-hidden="true"></i></a>
                                    
                                    </strong></td>` +
                            
                            ` <td><strong>
                                    <a href="format-template-view.php?id=${id}"><i class="fa fa-eye view" aria-hidden="true" style="margin-right:20px"></i> </a>
                                    <a href="edit-template.php?id=${id}"><i class="fa fa-pencil edit" aria-hidden="true" style="margin-right:20px"></i> </a>
                                    <a href="./controller/hard-delete-template.php?id=${id}"><i class="fa fa-trash delete" aria-hidden="true"></i></a>
                                    </strong></td>` 
                            
                            "</tr>";
                        
                        $("#filter-listing-table tbody").append(tr_str);

                    }
                }
                });
            
            
        });


        $('#downloadBtn').click(function() {
            // Serialize form data
            
            var formData = $('#filter_report_form').serialize();
            
            // Send AJAX request
            $.ajax({
                type: 'POST',
                url: './controller/download_juoi.php', // The URL of the PHP page
                data: formData,
                xhrFields: {
                    responseType: 'text'  // Important
                },
                success: function(response,status, xhr) {
                    // Handle the response from the PHP page
                    // $('#response').html(response);
                   
                    var disposition = xhr.getResponseHeader('Content-Disposition');
                    var filename = "output.csv"; // Default filename
                    if (disposition && disposition.indexOf('attachment') !== -1) {
                        var matches = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/.exec(disposition);
                        if (matches != null && matches[1]) { 
                            filename = matches[1].replace(/['"]/g, '');
                        }
                    }
                    alert(filename);
                    var blob = new Blob([response], { type: 'text/csv' });
                    var downloadUrl = URL.createObjectURL(blob);
                    

                    // Create a link element, use it to download the blob, then remove it
                    var a = document.createElement("a");
                    a.href = downloadUrl;
                    a.download = filename;
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);   
                    URL.revokeObjectURL(downloadUrl)
                },
                error: function(xhr, status, error) {
                    // Handle any errors
                    $('#response').html('An error occurred: ' + error);
                }
            });
        });


        // $('#dateInput').change(function() {
        //     var date = new Date($(this).val());
        //     // var month = date.toLocaleString('default', { month: 'long' }); // Get month name (e.g., January)
        //     var year = date.getFullYear(); // Get full year (e.g., 2024)
        //     var month = (date.getMonth() + 1).toString().padStart(2, '0');
        //     // Set the values in the month and year input fields
        //     $('#monthInput').val(month);
        //     $('#yearInput').val(year);
        // });


        $('#editFormDataButton').click(function() {
            // Define the parameters

            var id = $('input[name="id"]').val();
            var user_id = $('input[name="user_id"]').val();
            var role_id = $('input[name="role_id"]').val();
            var date = $('input[name="date"]').val();
            // var id = 15;
            // var user_id = 13;
            // var role_id = 2;
            // var date = '07/25/2024'; // You can dynamically get this value from a date picker or another input

            // Construct the URL
            var url = "edit-format-data.php?id=" + id + "&user_id=" + user_id + "&role_id=" + role_id + "&date=" + encodeURIComponent(date);

            // Perform the redirect using JavaScript
            window.location.href = url;
        });





        $("#filter_report_form").submit(function(e){
            e.preventDefault();
                $.ajax({
                url: './controller/filter_report.php',
                method:'post',
                dataType: 'JSON',
                data:$(this).serialize(),
                success: function(response){
                    // alert(response);
                    let data=JSON.stringify(response);
                    
                    if(Object.keys(response).length==0){
                        $('#alert-data').removeClass('hidden');
                        $('#alert-data').text('No Data Found !');
                        
                        $("#filter-report-table").addClass('hidden');
                        $('#default-filter-table_wrapper').addClass('hidden');
                        $('#default-filter-table').parents('div.dataTables_wrapper').first().hide();
                        $("#default-filter-table").addClass('hidden');

                        $('#filter-report-table_wrapper').addClass('hidden');
                        $('#filter-report-table').parents('div.dataTables_wrapper').first().hide();
                        $("#filter-report-table").addClass('hidden');
                    }
                    else{
                        $('#alert-data').addClass('hidden');

                        var len = Object.keys(response).length;
                    
                   
                    // $('#type-of-template-listing').text(heading_name);
                    $('#default-filter-table_wrapper').addClass('hidden');
                    $('#default-filter-table').parents('div.dataTables_wrapper').first().hide();
                    $("#default-filter-table").addClass('hidden');

                    $("#filter-report-table").removeClass('hidden');

                    if ($.fn.DataTable.isDataTable('#filter-report-table')) {
                        // Destroy the existing DataTable instance
                        $('#filter-report-table').DataTable().destroy();
                    }
                    // Destroy the existing DataTable instance
                    // $('#filter-report-table').DataTable().destroy();

                    // Show the parent div
                    $('#filter-report-table').parents('div.dataTables_wrapper').first().show();



                    
                    $('#filter-report-table tbody').empty();

                    // var link="<?php echo $_SESSION['link']; ?>";
                    // alert(link);

                    // $('#myLink').attr('href', link);

                   
                    
                    for(var i=0; i<len; i++){
                        // var id = response[i].id;
                        var id = Object.keys(response)[i];
                        var user_name= response[id].user_name;
                        var format_name = response[id].format_name;
                        var format_heading = response[id].format_heading;
                        var district_name= response[id].district_name;
                        var role= response[id].role;
                        var month= response[id].month;
                        var year= response[id].year;
                        var status=response[id].status;
                        var role_id=response[id].role_id;
                       
                        var user_id=response[id].user_id;
                        
                        
                        var format_id=response[id].format_id;
                        var district_id=response[id].district_id;

                        var user_role="<?php echo $_SESSION['user_role']; ?>";
                        

                        

                        
                        
                        
                        // if(status==1){
                        //     var status_icon="fa-toggle-on";
                        //     var active="active";
                        // }
                        // else{
                        //     var status_icon="fa-toggle-off";
                        //     var active="inactive";
                        // }
                        if(status==1){
                            var stats="Verified";
                        }
                        else if(status==3){
                            var stats="Semi-verified";
                        }
                        else{
                            var stats="Unverfied";
                        }

                        

                        var tr_str = `<tr>
                                                <td><strong>${i+1}</strong></td>
                                                <td><strong>${user_name}</strong></td>
                                                <td><strong>${district_name}</strong></td>
                                                <td><strong>${role}</strong></td>
                                                <td><strong>${format_name}</strong></td>
                                                
                                                <td><strong>${month}-${year}</strong></td>
                                                <td><strong>${stats}</strong></td>
                                                
                                                <td>`;
                        if(user_role && user_role=="admin"){
                            tr_str += `<a href="report-view.php?id=${format_id}&user_id=${user_id}&role_id=${role_id}&district_id=${district_id}&month=${month}&year=${year}"><i class="fa fa-eye view" aria-hidden="true" style="margin-right:20px"></i> </a>`;
                        }
                        else{
                            tr_str += ` <a href="report-view.php?id=${format_id}&user_id=${user_id}&role_id=${role_id}&month=${month}&year=${year}"><i class="fa fa-eye view" aria-hidden="true" style="margin-right:20px"></i> </a>
                                                    <!-- <a href="format-template-view.php?id=<?php echo $row['id']; ?>"><i class="fa fa-pencil edit" aria-hidden="true"></i> </a> -->
                                                    <a href="./controller/verify_data.php?id=${format_id}&user_id=${user_id}&role_id=${role_id}&month=${month}&year=${year}"><i class="fa fa-check-circle verified" aria-hidden="true" style="margin-right:20px"></i> </a>
                                                    <a href="./controller/unverify_data.php?id=${format_id}&user_id=${user_id}&role_id=${role_id}&month=${month}&year=${year}"><i class="fa fa-check-circle-o unverified" aria-hidden="true"></i> </a>`
                        }
                                               
                        tr_str += ` </td>
                                    </tr>`;                        
                                                
                        
                        $("#filter-report-table tbody").append(tr_str);
                    }
                    var table = $('#filter-report-table').DataTable({ 
                        select: false,
                        "columnDefs": [{
                            className: "Name", 
                            // "targets":[0],
                            "visible": false,
                            "searchable":false
                        }]
                    });

                    }

                    
                    
                }
            });
        });




    


        // $("#add_user_form").submit(function(e){
        //     e.preventDefault();
        //     $("#save_user_btn").val('Adding.....');
        //     $.ajax({
        //         url: './controller/add_user.php',
        //         method:'post',
        //         data: $(this).serialize(),
        //         success: function(response){
        //             // console.log(response);
        //            location.reload();
        //         }
        //     });
        // });

        $("#save_user_btn").click(function(e){
            e.preventDefault();
            $("#save_user_btn").val('Adding.....');
            var formData = $('#add_user_form').serialize();
            $.ajax({
                url: './controller/add_user.php',
                method:'post',
                data: formData,
                success: function(response){
                    // console.log(response);
                   location.reload();
                }
            });
        });




        

        




        

    

    });



    
   </script>


    <script>
    $(function() {
    $('input[name="filled_data_month_year"]').daterangepicker({
        singleDatePicker: true,
        showDropdowns: true,
        minYear: 1901,
        maxYear: parseInt(moment().format('YYYY'),10)
        }, 
    // function(start, end, label) {
    //     var years = moment().diff(start, 'years');
    //     alert("You are " + years + " years old!");
    // }
    );
    });
    </script>

    <script>

    $(document).ready(function() {
    
    
    
    var table = $('#default-filter-table').DataTable({ 
            select: false,
            "columnDefs": [{
                className: "Name", 
                // "targets":[0],
                "visible": false,
                "searchable":false
            }]
        });//End of create main table

        
    });


    function getDistrict(division){
            // alert(division);
            $.ajax({
                type:"GET",
                url:"./controller/fetch_districts.php",
                data:{division_id:division},
                success:function(response){
                    console.log(response);
                    $("#selectDistrict").html(response);
                }
            });
        }
    </script>
   <?php unset($_SESSION['alert-msg']); 
   unset($_SESSION['alert-type']);
   unset($_SESSION['alert_msg'])
   ?>
</body>
<!-- InstanceEnd --></html>
